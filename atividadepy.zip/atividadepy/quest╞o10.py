x = int(input("digite um numero inteiro: "))
y = int(input("digite um numero inteiro: "))
soma = 0
while x < y-1:
    x+=1
    soma += x
    print(soma)