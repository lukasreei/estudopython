x = []
contador = 0

while contador < 5:
    numero = float(input("digite um numero: "))
    x.append(numero)
    contador += 1

print("numeros digitados foram: ", x)
