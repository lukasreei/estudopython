while True:
    usuario = str(input("digite o nome de usuario: "))
    senha = str(input("digite a senha: "))

    if usuario == senha:
        print("não permitido")
        break
    else: 
        usuario != senha
        print("acesso permitido")
        break