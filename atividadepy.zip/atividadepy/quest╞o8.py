cont = 1

while cont < 50:
    print(cont)
    cont += 2