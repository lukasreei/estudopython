while True:
    nota = int(input("digite a nota: "))
    if nota <=10:
        print("nota valida")
        break
    else:
        print("valor errado ou invalido")