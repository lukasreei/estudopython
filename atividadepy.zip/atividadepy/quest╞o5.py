x = 1

while x <= 20:
    print(x, end="")
    x += 1
