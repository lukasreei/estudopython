x = int(input("digite um numero inteiro: "))
y = int(input("digite um numero inteiro: "))

while x < y-1:
    x+=1
    print(x)